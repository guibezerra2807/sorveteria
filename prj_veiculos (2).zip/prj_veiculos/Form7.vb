﻿Public Class Form7
    Private Sub Form7_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub txt_placa_KeyDown(sender As Object, e As KeyEventArgs) Handles txt_placa.KeyDown
        If e.KeyCode = Keys.Enter Then
            Try
                sql = "SELECT preco_diaria, marca, modelo, cor FROM veiculos WHERE placa = '" & txt_placa.Text & "'"
                rs = db.Execute(sql)

                If rs.EOF Then
                    MsgBox("Cliente não encontrado!")
                    Exit Sub
                End If

                txt_diaria.Text = rs.Fields("preco_diaria").Value
                txt_marca.Text = rs.Fields("marca").Value
                txt_modelo.Text = rs.Fields("modelo").Value
                txt_cor.Text = rs.Fields("cor").Value



            Catch ex As Exception
                MsgBox("Erro ao buscar Cliente: " & ex.Message)
            End Try
        End If
    End Sub

    Private Sub txt_placa_MaskInputRejected(sender As Object, e As MaskInputRejectedEventArgs) Handles txt_placa.MaskInputRejected

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            If Trim(txt_placa.Text) = "" Then
                MsgBox("Informe a placa para atualizar os dados!", MsgBoxStyle.Exclamation, "Aviso")
                Exit Sub
            End If

            sql = "UPDATE veiculos SET " &
                  "preco_diaria = '" & txt_diaria.Text.Replace("'", "''") & "', " &
                  "marca = '" & txt_marca.Text.Replace("'", "''") & "', " &
                  "modelo = '" & txt_modelo.Text.Replace("'", "''") & "', " &
                  "cor = '" & txt_cor.Text.Replace("'", "''") & "', " &
                  "WHERE placa = '" & txt_placa.Text.Replace("'", "''") & "'"

            db.Execute(sql)

            MsgBox("Dados alterados com sucesso!", MsgBoxStyle.Information, "Sucesso")
            Form2.Show()

        Catch ex As Exception
            MsgBox("Erro ao alterar os dados: " & ex.Message, MsgBoxStyle.Critical, "Erro")
        End Try
    End Sub
End Class