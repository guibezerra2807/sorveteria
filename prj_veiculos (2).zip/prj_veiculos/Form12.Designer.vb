﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form12
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form12))
        dgv_veiculosa = New DataGridView()
        ToolStrip1 = New ToolStrip()
        ToolStripLabel1 = New ToolStripLabel()
        txt_filtro = New ToolStripTextBox()
        ToolStripLabel2 = New ToolStripLabel()
        cmb_filtro = New ToolStripComboBox()
        ToolStripLabel3 = New ToolStripLabel()
        ToolStripButton1 = New ToolStripButton()
        CType(dgv_veiculosa, ComponentModel.ISupportInitialize).BeginInit()
        ToolStrip1.SuspendLayout()
        SuspendLayout()
        ' 
        ' dgv_veiculosa
        ' 
        dgv_veiculosa.AllowUserToAddRows = False
        dgv_veiculosa.AllowUserToDeleteRows = False
        dgv_veiculosa.BackgroundColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        dgv_veiculosa.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        dgv_veiculosa.Location = New Point(0, 30)
        dgv_veiculosa.Margin = New Padding(2)
        dgv_veiculosa.Name = "dgv_veiculosa"
        dgv_veiculosa.ReadOnly = True
        dgv_veiculosa.RowHeadersWidth = 62
        dgv_veiculosa.Size = New Size(1145, 532)
        dgv_veiculosa.TabIndex = 1
        ' 
        ' ToolStrip1
        ' 
        ToolStrip1.BackColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        ToolStrip1.Font = New Font("Perpetua Titling MT", 12.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        ToolStrip1.ImageScalingSize = New Size(20, 20)
        ToolStrip1.Items.AddRange(New ToolStripItem() {ToolStripLabel1, txt_filtro, ToolStripLabel2, cmb_filtro, ToolStripLabel3, ToolStripButton1})
        ToolStrip1.Location = New Point(0, 0)
        ToolStrip1.Name = "ToolStrip1"
        ToolStrip1.Size = New Size(1145, 28)
        ToolStrip1.TabIndex = 2
        ToolStrip1.Text = "ToolStrip1"
        ' 
        ' ToolStripLabel1
        ' 
        ToolStripLabel1.ForeColor = SystemColors.ButtonHighlight
        ToolStripLabel1.Name = "ToolStripLabel1"
        ToolStripLabel1.Size = New Size(112, 25)
        ToolStripLabel1.Text = "PESQUISE:"
        ' 
        ' txt_filtro
        ' 
        txt_filtro.Name = "txt_filtro"
        txt_filtro.Size = New Size(100, 28)
        ' 
        ' ToolStripLabel2
        ' 
        ToolStripLabel2.ForeColor = SystemColors.ButtonHighlight
        ToolStripLabel2.Name = "ToolStripLabel2"
        ToolStripLabel2.Size = New Size(107, 25)
        ToolStripLabel2.Text = "FILTRAR:"
        ' 
        ' cmb_filtro
        ' 
        cmb_filtro.Name = "cmb_filtro"
        cmb_filtro.Size = New Size(121, 28)
        ' 
        ' ToolStripLabel3
        ' 
        ToolStripLabel3.ForeColor = SystemColors.ButtonHighlight
        ToolStripLabel3.Name = "ToolStripLabel3"
        ToolStripLabel3.Size = New Size(227, 25)
        ToolStripLabel3.Text = "ATUALIZAR DADOS:"
        ' 
        ' ToolStripButton1
        ' 
        ToolStripButton1.BackColor = Color.FromArgb(CByte(255), CByte(224), CByte(192))
        ToolStripButton1.DisplayStyle = ToolStripItemDisplayStyle.Image
        ToolStripButton1.Image = CType(resources.GetObject("ToolStripButton1.Image"), Image)
        ToolStripButton1.ImageTransparentColor = Color.Magenta
        ToolStripButton1.Name = "ToolStripButton1"
        ToolStripButton1.Size = New Size(29, 25)
        ToolStripButton1.Text = "ToolStripButton1"
        ' 
        ' Form12
        ' 
        AutoScaleDimensions = New SizeF(8.0F, 20.0F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1145, 560)
        Controls.Add(ToolStrip1)
        Controls.Add(dgv_veiculosa)
        Name = "Form12"
        StartPosition = FormStartPosition.CenterScreen
        Text = "VEÍCULOS"
        CType(dgv_veiculosa, ComponentModel.ISupportInitialize).EndInit()
        ToolStrip1.ResumeLayout(False)
        ToolStrip1.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents dgv_veiculosa As DataGridView
    Friend WithEvents ToolStrip1 As ToolStrip
    Friend WithEvents ToolStripLabel1 As ToolStripLabel
    Friend WithEvents txt_filtro As ToolStripTextBox
    Friend WithEvents ToolStripLabel2 As ToolStripLabel
    Friend WithEvents cmb_filtro As ToolStripComboBox
    Friend WithEvents ToolStripLabel3 As ToolStripLabel
    Friend WithEvents ToolStripButton1 As ToolStripButton
End Class
