﻿Public Class Form8
    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmb_pagamento.SelectedIndexChanged

    End Sub

    Private Sub Form8_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cmb_pagamento.Items.Clear()
        cmb_pagamento.Items.Add("PIX")
        cmb_pagamento.Items.Add("Débito")
    End Sub

    Private Sub txt_placa_KeyDown(sender As Object, e As KeyEventArgs) Handles txt_placa.KeyDown
        If e.KeyCode = Keys.Enter Then
            Try
                sql = "SELECT modelo, marca, cor, preco_diaria FROM veiculos WHERE placa = '" & txt_placa.Text & "'"
                rs = db.Execute(sql)

                If rs.EOF Then
                    MsgBox("Veículo não encontrado!")
                    Exit Sub
                End If

                txt_modelo.Text = rs.Fields("modelo").Value
                txt_marca.Text = rs.Fields("marca").Value
                txt_diaria.Text = rs.Fields("preco_diaria").Value

                txt_modelo.ReadOnly = True
                txt_marca.ReadOnly = True
                txt_diaria.ReadOnly = True

            Catch ex As Exception
                MsgBox("Erro ao buscar veículo: " & ex.Message)
            End Try
        End If
    End Sub

    Private Sub dt_fim_ValueChanged(sender As Object, e As EventArgs) Handles dt_fim.ValueChanged, dt_inicio.ValueChanged
        Try
            Dim dias As Integer = DateDiff(DateInterval.Day, dt_inicio.Value, dt_fim.Value)

            If dias < 1 Then
                txt_final.Text = ""
                Exit Sub
            End If

            Dim diaria As Decimal = txt_diaria.Text
            txt_final.Text = dias * diaria

        Catch ex As Exception
            'Erro ignorado enquanto o usuário não preenche tudo
        End Try
    End Sub

    Private Sub btn_alugar_Click(sender As Object, e As EventArgs) Handles btn_alugar.Click
        Try
            '=========================================
            ' 0 - VERIFICAR SE A CNH JÁ TEM VEÍCULO ALUGADO
            '=========================================
            sql = "SELECT * FROM locacoes WHERE cnh_cliente='" & txt_cnh.Text & "' AND status='alugado'"
            rs = db.Execute(sql)

            If rs.EOF = False Then
                MsgBox("Já existe um veículo alugado cadastrado para esta CNH!", vbExclamation, "Atenção")
                Exit Sub
            End If

            '=========================================
            ' 1 - VALIDAR CAMPOS
            '=========================================
            If txt_cnh.Text = "" Or txt_placa.Text = "" Or
           txt_final.Text = "" Or cmb_pagamento.Text = "" Then

                MsgBox("Preencha todos os campos obrigatórios!", vbExclamation)
                Exit Sub
            End If

            '=========================================
            ' 2 - PEGAR DATAS
            '=========================================
            Dim dataInicio As String = dt_inicio.Value.ToString("yyyy-MM-dd")
            Dim dataFim As String = dt_fim.Value.ToString("yyyy-MM-dd")
            Dim dataPagamento As String = Date.Now.ToString("yyyy-MM-dd")

            '=========================================
            ' 3 - INSERIR LOCAÇÃO
            '=========================================
            sql = "INSERT INTO locacoes (cnh_cliente, placa_veiculo, data_inicio, data_fim, valor_total, status) VALUES (" &
              "'" & txt_cnh.Text & "'," &
              "'" & txt_placa.Text & "'," &
              "'" & dataInicio & "'," &
              "'" & dataFim & "'," &
              "'" & txt_final.Text & "'," &
              "'alugado')"

            db.Execute(sql)

            '=========================================
            ' 4 - PEGAR O ID
            '=========================================
            sql = "SELECT MAX(id) AS id FROM locacoes"
            rs = db.Execute(sql)
            Dim idLocacao As Integer = rs.Fields("id").Value

            '=========================================
            ' 5 - INSERIR PAGAMENTO
            '=========================================
            sql = "INSERT INTO pagamentos (id_locacao, valor, metodo, data_pagamento) VALUES (" &
              idLocacao & "," &
              "'" & txt_final.Text & "'," &
              "'" & cmb_pagamento.Text & "'," &
              "'" & dataPagamento & "')"

            db.Execute(sql)

            MsgBox("Locação cadastrada e pagamento registrado!", vbInformation)

        Catch ex As Exception
            MsgBox("Erro: " & ex.Message, vbCritical)
        End Try

    End Sub

    Private Sub txt_cnh_KeyDown(sender As Object, e As KeyEventArgs) Handles txt_cnh.KeyDown
        If e.KeyCode = Keys.Enter Then
            Try
                sql = "SELECT nome, telefone, email FROM clientes WHERE cnh = '" & txt_cnh.Text & "'"
                rs = db.Execute(sql)

                If rs.EOF Then
                    MsgBox("Cliente não encontrado!")
                    Exit Sub
                End If

                txt_nome.Text = rs.Fields("nome").Value
                txt_fone.Text = rs.Fields("telefone").Value
                txt_email.Text = rs.Fields("email").Value

                txt_nome.ReadOnly = True
                txt_fone.ReadOnly = True
                txt_email.ReadOnly = True

            Catch ex As Exception
                MsgBox("Erro ao buscar Cliente: " & ex.Message)
            End Try
        End If
    End Sub

    Private Sub txt_placa_MaskInputRejected(sender As Object, e As MaskInputRejectedEventArgs) Handles txt_placa.MaskInputRejected

    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub
End Class


