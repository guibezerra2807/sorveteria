﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form11
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        dgv_locacoes = New DataGridView()
        ToolStrip1 = New ToolStrip()
        ToolStripLabel1 = New ToolStripLabel()
        ToolStripTextBox1 = New ToolStripTextBox()
        ToolStripLabel2 = New ToolStripLabel()
        cmb_filtro2 = New ToolStripComboBox()
        CType(dgv_locacoes, ComponentModel.ISupportInitialize).BeginInit()
        ToolStrip1.SuspendLayout()
        SuspendLayout()
        ' 
        ' dgv_locacoes
        ' 
        dgv_locacoes.BackgroundColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        dgv_locacoes.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        dgv_locacoes.Location = New Point(-3, 31)
        dgv_locacoes.Name = "dgv_locacoes"
        dgv_locacoes.RowHeadersWidth = 51
        dgv_locacoes.Size = New Size(1251, 530)
        dgv_locacoes.TabIndex = 0
        ' 
        ' ToolStrip1
        ' 
        ToolStrip1.BackColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        ToolStrip1.Font = New Font("Perpetua Titling MT", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        ToolStrip1.ImageScalingSize = New Size(20, 20)
        ToolStrip1.Items.AddRange(New ToolStripItem() {ToolStripLabel1, ToolStripTextBox1, ToolStripLabel2, cmb_filtro2})
        ToolStrip1.Location = New Point(0, 0)
        ToolStrip1.Name = "ToolStrip1"
        ToolStrip1.Size = New Size(1250, 28)
        ToolStrip1.TabIndex = 1
        ToolStrip1.Text = "ToolStrip1"
        ' 
        ' ToolStripLabel1
        ' 
        ToolStripLabel1.ForeColor = SystemColors.ButtonHighlight
        ToolStripLabel1.Name = "ToolStripLabel1"
        ToolStripLabel1.Size = New Size(112, 25)
        ToolStripLabel1.Text = "PESQUISE:"
        ' 
        ' ToolStripTextBox1
        ' 
        ToolStripTextBox1.Name = "ToolStripTextBox1"
        ToolStripTextBox1.Size = New Size(100, 28)
        ' 
        ' ToolStripLabel2
        ' 
        ToolStripLabel2.ForeColor = SystemColors.ButtonHighlight
        ToolStripLabel2.Name = "ToolStripLabel2"
        ToolStripLabel2.Size = New Size(107, 25)
        ToolStripLabel2.Text = "FILTRAR:"
        ' 
        ' cmb_filtro2
        ' 
        cmb_filtro2.Name = "cmb_filtro2"
        cmb_filtro2.Size = New Size(121, 28)
        ' 
        ' Form11
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1250, 560)
        Controls.Add(ToolStrip1)
        Controls.Add(dgv_locacoes)
        Name = "Form11"
        StartPosition = FormStartPosition.CenterScreen
        Text = "ALUGUEL"
        CType(dgv_locacoes, ComponentModel.ISupportInitialize).EndInit()
        ToolStrip1.ResumeLayout(False)
        ToolStrip1.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents dgv_locacoes As DataGridView
    Friend WithEvents ToolStrip1 As ToolStrip
    Friend WithEvents ToolStripLabel1 As ToolStripLabel
    Friend WithEvents ToolStripTextBox1 As ToolStripTextBox
    Friend WithEvents ToolStripLabel2 As ToolStripLabel
    Friend WithEvents cmb_filtro2 As ToolStripComboBox
End Class
