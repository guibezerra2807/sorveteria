﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form7
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        txt_diaria = New TextBox()
        txt_marca = New TextBox()
        Label10 = New Label()
        txt_placa = New MaskedTextBox()
        Label7 = New Label()
        Label4 = New Label()
        Label3 = New Label()
        Label2 = New Label()
        Button1 = New Button()
        Label1 = New Label()
        txt_cor = New TextBox()
        txt_modelo = New MaskedTextBox()
        Label9 = New Label()
        SuspendLayout()
        ' 
        ' txt_diaria
        ' 
        txt_diaria.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        txt_diaria.Location = New Point(651, 205)
        txt_diaria.Margin = New Padding(2)
        txt_diaria.Name = "txt_diaria"
        txt_diaria.Size = New Size(165, 27)
        txt_diaria.TabIndex = 61
        ' 
        ' txt_marca
        ' 
        txt_marca.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        txt_marca.Location = New Point(108, 332)
        txt_marca.Margin = New Padding(2)
        txt_marca.Name = "txt_marca"
        txt_marca.Size = New Size(165, 27)
        txt_marca.TabIndex = 60
        ' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.BackColor = Color.White
        Label10.Font = New Font("Perpetua Titling MT", 28.2F)
        Label10.ForeColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        Label10.Location = New Point(475, 24)
        Label10.Name = "Label10"
        Label10.Size = New Size(230, 55)
        Label10.TabIndex = 59
        Label10.Text = "VEÍCULO"
        ' 
        ' txt_placa
        ' 
        txt_placa.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        txt_placa.Location = New Point(108, 205)
        txt_placa.Mask = "LLL0000"
        txt_placa.Name = "txt_placa"
        txt_placa.Size = New Size(165, 27)
        txt_placa.TabIndex = 55
        txt_placa.TextAlign = HorizontalAlignment.Center
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.BackColor = Color.IndianRed
        Label7.Location = New Point(651, 183)
        Label7.Margin = New Padding(2, 0, 2, 0)
        Label7.Name = "Label7"
        Label7.Size = New Size(130, 20)
        Label7.TabIndex = 54
        Label7.Text = "VALOR DA DIÁRIA"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.BackColor = Color.IndianRed
        Label4.Location = New Point(378, 182)
        Label4.Margin = New Padding(2, 0, 2, 0)
        Label4.Name = "Label4"
        Label4.Size = New Size(38, 20)
        Label4.TabIndex = 53
        Label4.Text = "COR"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.BackColor = Color.IndianRed
        Label3.Location = New Point(108, 310)
        Label3.Margin = New Padding(2, 0, 2, 0)
        Label3.Name = "Label3"
        Label3.Size = New Size(60, 20)
        Label3.TabIndex = 52
        Label3.Text = "MARCA"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.BackColor = Color.IndianRed
        Label2.Location = New Point(108, 182)
        Label2.Margin = New Padding(2, 0, 2, 0)
        Label2.Name = "Label2"
        Label2.Size = New Size(53, 20)
        Label2.TabIndex = 51
        Label2.Text = "PLACA"
        ' 
        ' Button1
        ' 
        Button1.BackColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        Button1.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button1.ForeColor = Color.White
        Button1.Location = New Point(344, 477)
        Button1.Margin = New Padding(2)
        Button1.Name = "Button1"
        Button1.Size = New Size(236, 47)
        Button1.TabIndex = 50
        Button1.Text = "SALVAR"
        Button1.UseVisualStyleBackColor = False
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BackColor = Color.IndianRed
        Label1.Location = New Point(378, 310)
        Label1.Margin = New Padding(2, 0, 2, 0)
        Label1.Name = "Label1"
        Label1.Size = New Size(69, 20)
        Label1.TabIndex = 49
        Label1.Text = "MODELO"
        ' 
        ' txt_cor
        ' 
        txt_cor.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        txt_cor.Location = New Point(378, 205)
        txt_cor.Margin = New Padding(2)
        txt_cor.Name = "txt_cor"
        txt_cor.Size = New Size(165, 27)
        txt_cor.TabIndex = 48
        ' 
        ' txt_modelo
        ' 
        txt_modelo.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        txt_modelo.Location = New Point(378, 332)
        txt_modelo.Margin = New Padding(2)
        txt_modelo.Name = "txt_modelo"
        txt_modelo.Size = New Size(362, 27)
        txt_modelo.TabIndex = 47
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.BackColor = Color.White
        Label9.Font = New Font("Perpetua Titling MT", 28.2F)
        Label9.ForeColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        Label9.Location = New Point(207, 24)
        Label9.Name = "Label9"
        Label9.Size = New Size(287, 55)
        Label9.TabIndex = 56
        Label9.Text = "ATUALIZAR"
        ' 
        ' Form7
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.White
        ClientSize = New Size(914, 560)
        Controls.Add(txt_diaria)
        Controls.Add(txt_marca)
        Controls.Add(Label10)
        Controls.Add(Label9)
        Controls.Add(txt_placa)
        Controls.Add(Label7)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Button1)
        Controls.Add(Label1)
        Controls.Add(txt_cor)
        Controls.Add(txt_modelo)
        ForeColor = SystemColors.ControlLightLight
        Name = "Form7"
        StartPosition = FormStartPosition.CenterScreen
        Text = "ATUALIZAR VEÍCULO"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents txt_diaria As TextBox
    Friend WithEvents txt_marca As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents txt_placa As MaskedTextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents txt_cor As TextBox
    Friend WithEvents txt_modelo As MaskedTextBox
    Friend WithEvents Label9 As Label
End Class
