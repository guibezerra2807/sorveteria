﻿Imports System.IO

Public Class Form6
    Private Sub pic_veiculo_Click(sender As Object, e As EventArgs) Handles pic_veiculo.Click

    End Sub

    Private Sub btn_imagem_Click(sender As Object, e As EventArgs) Handles btn_imagem.Click
        Dim ofd As New OpenFileDialog()
        ofd.Filter = "Arquivos de imagem|*.jpg;*.jpeg;*.png;*.bmp"

        If ofd.ShowDialog() = DialogResult.OK Then
            pic_veiculo.Image = Image.FromFile(ofd.FileName)
        End If


    End Sub

    Private Sub txt_cadastrar_Click(sender As Object, e As EventArgs) Handles txt_cadastrar.Click
        Try
            ' Verifica se todos os campos obrigatórios estão preenchidos
            If txt_placa.Text = "" Or txt_modelo.Text = "" Or txt_marca.Text = "" Or
           txt_ano.Text = "" Or txt_diaria.Text = "" Or txt_cor.Text = "" Then
                MsgBox("Preencha todos os campos antes de salvar.", MsgBoxStyle.Exclamation, "Aviso")
                Exit Sub
            End If

            ' Converte a imagem para bytes (caso queira salvar imagem no banco)
            Dim imagemBytes() As Byte = Nothing
            If Not pic_veiculo.Image Is Nothing Then
                Using ms As New System.IO.MemoryStream()
                    pic_veiculo.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg)
                    imagemBytes = ms.ToArray()
                End Using
            End If

            ' Define o valor inicial de disponibilidade (1 = disponível)
            Dim disponivel As Integer = 1

            ' Monta o comando SQL com o campo "cor"
            sql = "INSERT INTO veiculos (placa, modelo, marca, cor, ano, disponivel, preco_diaria, foto) VALUES (" &
              $"'{txt_placa.Text}', " &
              $"'{txt_modelo.Text}', " &
              $"'{txt_marca.Text}', " &
              $"'{txt_cor.Text}', " &
              $"'{txt_ano.Text}', " &
              $"{disponivel}, " &
              $"'{txt_diaria.Text}', ?)"

            ' Cria o comando ADODB
            Dim cmd As New ADODB.Command
            With cmd
                .ActiveConnection = db
                .CommandText = sql
                .CommandType = ADODB.CommandTypeEnum.adCmdText

                ' Adiciona a imagem como parâmetro binário, se existir
                If Not imagemBytes Is Nothing Then
                    .Parameters.Append(.CreateParameter("imagem", ADODB.DataTypeEnum.adLongVarBinary,
                                                    ADODB.ParameterDirectionEnum.adParamInput,
                                                    imagemBytes.Length, imagemBytes))
                End If

                ' Executa o comando SQL
                .Execute()
            End With

            MsgBox("Veículo cadastrado com sucesso e marcado como disponível!", MsgBoxStyle.Information, "Sucesso")

            ' Limpa os campos após salvar
            txt_placa.Clear()
            txt_modelo.Clear()
            txt_marca.Clear()
            txt_cor.Clear()
            txt_ano.Clear()
            txt_diaria.Clear()
            pic_veiculo.Image = Nothing

        Catch ex As Exception
            MsgBox("Erro ao cadastrar veículo: " & ex.Message, MsgBoxStyle.Critical, "Erro")
        End Try
    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub Form6_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class