﻿Public Class Form12

    Private Sub Form9_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        grid_veiculos()
        carregar_veiculos()
        cmb_filtro.Items.Clear()
        cmb_filtro.Items.Add("Placa")
        cmb_filtro.Items.Add("Marca")
        cmb_filtro.Items.Add("Modelo")
        cmb_filtro.SelectedIndex = 1
    End Sub

    Sub grid_veiculos()
        dgv_veiculosa.Columns.Clear()

        dgv_veiculosa.Columns.Add("placa", "Placa")
        dgv_veiculosa.Columns.Add("modelo", "Modelo")
        dgv_veiculosa.Columns.Add("ano", "Ano")
        dgv_veiculosa.Columns.Add("cor", "Cor")

        Dim btnExcluir As New DataGridViewButtonColumn()
        btnExcluir.Name = "colExcluir"
        btnExcluir.HeaderText = "Excluir"
        btnExcluir.Text = "Excluir"
        btnExcluir.UseColumnTextForButtonValue = True
        btnExcluir.Width = 70
        dgv_veiculosa.Columns.Add(btnExcluir)
    End Sub
    Sub carregar_veiculos()
        Try
            sql = "SELECT placa, marca, modelo, ano, cor, preco_diaria, foto " &
                  "FROM veiculos " &
                  "WHERE placa NOT IN (SELECT placa_veiculo FROM locacoes WHERE status='alugado')"

            rs = db.Execute(sql)

            dgv_veiculosa.Rows.Clear()

            While Not rs.EOF
                dgv_veiculosa.Rows.Add(
                    rs.Fields("placa").Value,
                    rs.Fields("marca").Value,
                    rs.Fields("modelo").Value,
                    rs.Fields("ano").Value,
                    rs.Fields("cor").Value
                )
                rs.MoveNext()
            End While

        Catch ex As Exception
            MsgBox("Erro ao carregar veículos: " & ex.Message, MsgBoxStyle.Critical, "Erro")
        End Try
    End Sub

    Private Sub dgv_veiculosa_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv_veiculosa.CellContentClick
        Try
            If e.RowIndex < 0 Then Exit Sub

            Dim nomeColuna As String = dgv_veiculosa.Columns(e.ColumnIndex).Name

            '----- EXCLUIR -----
            If nomeColuna = "colExcluir" Then

                Dim placaExcluir As String = dgv_veiculosa.Rows(e.RowIndex).Cells("placa").Value.ToString()

                If MsgBox("Deseja excluir o veículo " & placaExcluir & "?", MsgBoxStyle.YesNo + MsgBoxStyle.Question) = MsgBoxResult.Yes Then

                    sql = "DELETE FROM veiculos WHERE placa='" & placaExcluir.Replace("'", "''") & "'"
                    db.Execute(sql)

                    MsgBox("Veículo excluído!", MsgBoxStyle.Information, "Sucesso")

                    carregar_veiculos()
                End If

                Exit Sub
            End If

            '----- SELECIONAR -----

        Catch ex As Exception
            MsgBox("Erro: " & ex.Message)
        End Try
    End Sub

    Private Sub ToolStripButton1_Click(sender As Object, e As EventArgs)
        Form7.Show()
    End Sub
End Class