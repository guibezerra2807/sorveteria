﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form5
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form5))
        txt_csenha = New MaskedTextBox()
        txt_nome = New MaskedTextBox()
        txt_senha = New TextBox()
        txt_email = New TextBox()
        Label1 = New Label()
        btn_gravar = New Button()
        Label2 = New Label()
        Label3 = New Label()
        Label4 = New Label()
        Label5 = New Label()
        Label6 = New Label()
        Label7 = New Label()
        Label8 = New Label()
        txt_cnh = New MaskedTextBox()
        txt_fone = New MaskedTextBox()
        txt_cep = New MaskedTextBox()
        Label9 = New Label()
        PictureBox1 = New PictureBox()
        PictureBox2 = New PictureBox()
        dtp_nascimento = New DateTimePicker()
        Button1 = New Button()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' txt_csenha
        ' 
        txt_csenha.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        txt_csenha.Location = New Point(846, 363)
        txt_csenha.Margin = New Padding(2)
        txt_csenha.Name = "txt_csenha"
        txt_csenha.Size = New Size(266, 27)
        txt_csenha.TabIndex = 0
        ' 
        ' txt_nome
        ' 
        txt_nome.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        txt_nome.Location = New Point(79, 252)
        txt_nome.Margin = New Padding(2)
        txt_nome.Name = "txt_nome"
        txt_nome.Size = New Size(362, 27)
        txt_nome.TabIndex = 2
        ' 
        ' txt_senha
        ' 
        txt_senha.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        txt_senha.Location = New Point(526, 363)
        txt_senha.Margin = New Padding(2)
        txt_senha.Name = "txt_senha"
        txt_senha.Size = New Size(266, 27)
        txt_senha.TabIndex = 5
        ' 
        ' txt_email
        ' 
        txt_email.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        txt_email.Location = New Point(79, 363)
        txt_email.Margin = New Padding(2)
        txt_email.Name = "txt_email"
        txt_email.Size = New Size(378, 27)
        txt_email.TabIndex = 7
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BackColor = Color.FromArgb(CByte(192), CByte(64), CByte(0))
        Label1.Location = New Point(79, 229)
        Label1.Margin = New Padding(2, 0, 2, 0)
        Label1.Name = "Label1"
        Label1.Size = New Size(52, 20)
        Label1.TabIndex = 8
        Label1.Text = "NOME"
        ' 
        ' btn_gravar
        ' 
        btn_gravar.BackColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        btn_gravar.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btn_gravar.ForeColor = Color.White
        btn_gravar.Location = New Point(846, 454)
        btn_gravar.Margin = New Padding(2)
        btn_gravar.Name = "btn_gravar"
        btn_gravar.Size = New Size(231, 56)
        btn_gravar.TabIndex = 9
        btn_gravar.Text = "CADASTRAR"
        btn_gravar.UseVisualStyleBackColor = False
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.BackColor = Color.FromArgb(CByte(192), CByte(64), CByte(0))
        Label2.Location = New Point(79, 133)
        Label2.Margin = New Padding(2, 0, 2, 0)
        Label2.Name = "Label2"
        Label2.Size = New Size(40, 20)
        Label2.TabIndex = 10
        Label2.Text = "CNH"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.BackColor = Color.FromArgb(CByte(192), CByte(64), CByte(0))
        Label3.Location = New Point(463, 227)
        Label3.Margin = New Padding(2, 0, 2, 0)
        Label3.Name = "Label3"
        Label3.Size = New Size(165, 20)
        Label3.TabIndex = 11
        Label3.Text = "DATA DE NASCIMENTO"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.BackColor = Color.FromArgb(CByte(192), CByte(64), CByte(0))
        Label4.Location = New Point(79, 341)
        Label4.Margin = New Padding(2, 0, 2, 0)
        Label4.Name = "Label4"
        Label4.Size = New Size(57, 20)
        Label4.TabIndex = 12
        Label4.Text = "E-MAIL"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.BackColor = Color.FromArgb(CByte(192), CByte(64), CByte(0))
        Label5.Location = New Point(846, 341)
        Label5.Margin = New Padding(2, 0, 2, 0)
        Label5.Name = "Label5"
        Label5.Size = New Size(144, 20)
        Label5.TabIndex = 13
        Label5.Text = "CONFIRMAR SENHA"
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.BackColor = Color.FromArgb(CByte(192), CByte(64), CByte(0))
        Label6.Location = New Point(846, 229)
        Label6.Margin = New Padding(2, 0, 2, 0)
        Label6.Name = "Label6"
        Label6.Size = New Size(34, 20)
        Label6.TabIndex = 14
        Label6.Text = "CEP"
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.BackColor = Color.FromArgb(CByte(192), CByte(64), CByte(0))
        Label7.Location = New Point(649, 229)
        Label7.Margin = New Padding(2, 0, 2, 0)
        Label7.Name = "Label7"
        Label7.Size = New Size(46, 20)
        Label7.TabIndex = 15
        Label7.Text = "FONE"
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.BackColor = Color.FromArgb(CByte(192), CByte(64), CByte(0))
        Label8.Location = New Point(526, 341)
        Label8.Margin = New Padding(2, 0, 2, 0)
        Label8.Name = "Label8"
        Label8.Size = New Size(57, 20)
        Label8.TabIndex = 16
        Label8.Text = "SENHA"
        ' 
        ' txt_cnh
        ' 
        txt_cnh.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        txt_cnh.Location = New Point(79, 156)
        txt_cnh.Mask = "00000000000"
        txt_cnh.Name = "txt_cnh"
        txt_cnh.Size = New Size(165, 27)
        txt_cnh.TabIndex = 17
        txt_cnh.TextAlign = HorizontalAlignment.Center
        ' 
        ' txt_fone
        ' 
        txt_fone.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        txt_fone.Location = New Point(649, 252)
        txt_fone.Mask = "(99) 00000-0000"
        txt_fone.Name = "txt_fone"
        txt_fone.Size = New Size(165, 27)
        txt_fone.TabIndex = 19
        ' 
        ' txt_cep
        ' 
        txt_cep.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        txt_cep.Location = New Point(846, 252)
        txt_cep.Mask = "99999999"
        txt_cep.Name = "txt_cep"
        txt_cep.Size = New Size(266, 27)
        txt_cep.TabIndex = 20
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Font = New Font("Palatino Linotype", 28.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label9.ForeColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        Label9.Location = New Point(442, 35)
        Label9.Name = "Label9"
        Label9.Size = New Size(292, 63)
        Label9.TabIndex = 21
        Label9.Text = "CADASTRO"
        ' 
        ' PictureBox1
        ' 
        PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), Image)
        PictureBox1.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox1.Location = New Point(12, -19)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(133, 124)
        PictureBox1.SizeMode = PictureBoxSizeMode.Zoom
        PictureBox1.TabIndex = 22
        PictureBox1.TabStop = False
        ' 
        ' PictureBox2
        ' 
        PictureBox2.BackgroundImage = CType(resources.GetObject("PictureBox2.BackgroundImage"), Image)
        PictureBox2.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox2.Location = New Point(1011, 2)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(133, 124)
        PictureBox2.SizeMode = PictureBoxSizeMode.Zoom
        PictureBox2.TabIndex = 23
        PictureBox2.TabStop = False
        ' 
        ' dtp_nascimento
        ' 
        dtp_nascimento.CalendarMonthBackground = Color.White
        dtp_nascimento.Format = DateTimePickerFormat.Short
        dtp_nascimento.Location = New Point(463, 250)
        dtp_nascimento.Name = "dtp_nascimento"
        dtp_nascimento.Size = New Size(143, 27)
        dtp_nascimento.TabIndex = 24
        ' 
        ' Button1
        ' 
        Button1.BackColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        Button1.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button1.ForeColor = Color.White
        Button1.Location = New Point(79, 454)
        Button1.Margin = New Padding(2)
        Button1.Name = "Button1"
        Button1.Size = New Size(254, 56)
        Button1.TabIndex = 25
        Button1.Text = "VOLTAR"
        Button1.UseVisualStyleBackColor = False
        ' 
        ' Form5
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.White
        ClientSize = New Size(1145, 560)
        Controls.Add(Button1)
        Controls.Add(dtp_nascimento)
        Controls.Add(PictureBox2)
        Controls.Add(PictureBox1)
        Controls.Add(Label9)
        Controls.Add(txt_cep)
        Controls.Add(txt_fone)
        Controls.Add(txt_cnh)
        Controls.Add(Label8)
        Controls.Add(Label7)
        Controls.Add(Label6)
        Controls.Add(Label5)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(btn_gravar)
        Controls.Add(Label1)
        Controls.Add(txt_email)
        Controls.Add(txt_senha)
        Controls.Add(txt_nome)
        Controls.Add(txt_csenha)
        ForeColor = SystemColors.ControlLightLight
        Margin = New Padding(2)
        Name = "Form5"
        StartPosition = FormStartPosition.CenterScreen
        Text = "CADASTRO DE CONTA"
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents txt_csenha As MaskedTextBox
    Friend WithEvents txt_nome As MaskedTextBox
    Friend WithEvents txt_senha As TextBox
    Friend WithEvents txt_email As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents btn_gravar As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents txt_cnh As MaskedTextBox
    Friend WithEvents txt_fone As MaskedTextBox
    Friend WithEvents txt_cep As MaskedTextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents dtp_nascimento As DateTimePicker
    Friend WithEvents Button1 As Button
End Class
