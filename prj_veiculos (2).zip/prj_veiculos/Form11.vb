﻿Public Class Form11

    Private Sub Form11_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        configurar_grid()
        carregar_locacoes()
        cmb_filtro2.Items.Clear()
        cmb_filtro2.Items.Add("Placa")
        cmb_filtro2.Items.Add("Marca")
        cmb_filtro2.Items.Add("Modelo")
        cmb_filtro2.SelectedIndex = 1
    End Sub

    Sub configurar_grid()
        dgv_locacoes.Columns.Clear()

        dgv_locacoes.Columns.Add("id", "ID")
        dgv_locacoes.Columns.Add("cnh_cliente", "CNH do Cliente")
        dgv_locacoes.Columns.Add("placa_veiculo", "Placa do Veículo")
        dgv_locacoes.Columns.Add("data_inicio", "Data Início")
        dgv_locacoes.Columns.Add("data_fim", "Data Fim")
        dgv_locacoes.Columns.Add("valor_total", "Valor Total")
        dgv_locacoes.Columns.Add("status", "Status")

        ' BOTÃO DEVOLVER
        Dim btn As New DataGridViewButtonColumn()
        btn.HeaderText = "Ações"
        btn.Name = "btn_devolver"
        btn.Text = "Devolver"
        btn.UseColumnTextForButtonValue = True
        dgv_locacoes.Columns.Add(btn)
    End Sub

    Sub carregar_locacoes()
        Try
            sql = "SELECT * FROM locacoes WHERE status='alugado'"
            rs = db.Execute(sql)

            dgv_locacoes.Rows.Clear()

            Do Until rs.EOF
                dgv_locacoes.Rows.Add(
                rs.Fields("id").Value.ToString(),
                rs.Fields("cnh_cliente").Value.ToString(),
                rs.Fields("placa_veiculo").Value.ToString(),
                rs.Fields("data_inicio").Value.ToString(),
                rs.Fields("data_fim").Value.ToString(),
                rs.Fields("valor_total").Value.ToString(),
                rs.Fields("status").Value.ToString()
            )
                rs.MoveNext()
            Loop

        Catch ex As Exception
            MsgBox("Erro ao carregar locações: " & ex.Message, MsgBoxStyle.Critical, "Erro")
        End Try
    End Sub

    Private Sub dgv_locacoes_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv_locacoes.CellClick
        Try
            If e.RowIndex < 0 Then Exit Sub

            If dgv_locacoes.Columns(e.ColumnIndex).Name = "btn_devolver" Then

                Dim id_loca As String = dgv_locacoes.Rows(e.RowIndex).Cells("id").Value.ToString()
                Dim placa As String = dgv_locacoes.Rows(e.RowIndex).Cells("placa_veiculo").Value.ToString()

                If MsgBox("Confirmar devolução?", MsgBoxStyle.YesNo + MsgBoxStyle.Question) = MsgBoxResult.No Then
                    Exit Sub
                End If

                ' Atualiza locação
                sql = $"UPDATE locacoes SET status='finalizado' WHERE id={id_loca}"
                db.Execute(sql)

                ' Libera o veículo
                sql = $"UPDATE veiculos SET disponivel=1 WHERE placa='{placa}'"
                db.Execute(sql)

                MsgBox("Veículo devolvido com sucesso!", MsgBoxStyle.Information)

                ' Recarrega grid de locações
                carregar_locacoes()

                ' Atualiza grid de veículos disponíveis no Form9 (se ele estiver aberto)
                If Application.OpenForms().OfType(Of Form9).Any() Then
                    Dim f As Form9 = Application.OpenForms().OfType(Of Form9).First()
                    f.carregar_veiculos() ' <- atualiza automaticamente o grid lá
                End If

            End If

        Catch ex As Exception
            MsgBox("Erro ao devolver: " & ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Sub dgv_locacoes_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv_locacoes.CellContentClick

    End Sub

    Private Sub ToolStripButton1_Click(sender As Object, e As EventArgs)
        Form7.Show()
    End Sub

    Private Sub ToolStripComboBox1_Click(sender As Object, e As EventArgs) Handles cmb_filtro2.Click

    End Sub
End Class