﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form10
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        dgv_dados = New DataGridView()
        Column1 = New DataGridViewTextBoxColumn()
        Column2 = New DataGridViewTextBoxColumn()
        Column3 = New DataGridViewTextBoxColumn()
        Column4 = New DataGridViewTextBoxColumn()
        Column5 = New DataGridViewTextBoxColumn()
        ToolStripLabel1 = New ToolStripLabel()
        txt_pesquisa = New ToolStripTextBox()
        ToolStripLabel2 = New ToolStripLabel()
        cmb_filtro = New ToolStripComboBox()
        ToolStrip1 = New ToolStrip()
        CType(dgv_dados, ComponentModel.ISupportInitialize).BeginInit()
        ToolStrip1.SuspendLayout()
        SuspendLayout()
        ' 
        ' dgv_dados
        ' 
        dgv_dados.AllowUserToAddRows = False
        dgv_dados.AllowUserToDeleteRows = False
        dgv_dados.BackgroundColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        dgv_dados.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        dgv_dados.Columns.AddRange(New DataGridViewColumn() {Column1, Column2, Column3, Column4, Column5})
        dgv_dados.Location = New Point(0, 31)
        dgv_dados.Name = "dgv_dados"
        dgv_dados.ReadOnly = True
        dgv_dados.RowHeadersWidth = 51
        dgv_dados.Size = New Size(1145, 536)
        dgv_dados.TabIndex = 0
        ' 
        ' Column1
        ' 
        Column1.HeaderText = "Column1"
        Column1.MinimumWidth = 6
        Column1.Name = "Column1"
        Column1.ReadOnly = True
        Column1.Width = 125
        ' 
        ' Column2
        ' 
        Column2.HeaderText = "Column2"
        Column2.MinimumWidth = 6
        Column2.Name = "Column2"
        Column2.ReadOnly = True
        Column2.Width = 125
        ' 
        ' Column3
        ' 
        Column3.HeaderText = "Column3"
        Column3.MinimumWidth = 6
        Column3.Name = "Column3"
        Column3.ReadOnly = True
        Column3.Width = 125
        ' 
        ' Column4
        ' 
        Column4.HeaderText = "Column4"
        Column4.MinimumWidth = 6
        Column4.Name = "Column4"
        Column4.ReadOnly = True
        Column4.Width = 125
        ' 
        ' Column5
        ' 
        Column5.HeaderText = "Column5"
        Column5.MinimumWidth = 6
        Column5.Name = "Column5"
        Column5.ReadOnly = True
        Column5.Width = 125
        ' 
        ' ToolStripLabel1
        ' 
        ToolStripLabel1.ForeColor = SystemColors.ButtonHighlight
        ToolStripLabel1.Name = "ToolStripLabel1"
        ToolStripLabel1.Size = New Size(112, 25)
        ToolStripLabel1.Text = "PESQUISE:"
        ' 
        ' txt_pesquisa
        ' 
        txt_pesquisa.Name = "txt_pesquisa"
        txt_pesquisa.Size = New Size(100, 28)
        ' 
        ' ToolStripLabel2
        ' 
        ToolStripLabel2.ForeColor = SystemColors.ButtonHighlight
        ToolStripLabel2.Name = "ToolStripLabel2"
        ToolStripLabel2.Size = New Size(302, 25)
        ToolStripLabel2.Text = "ESCOLHA UM PARAMETRO:"
        ' 
        ' cmb_filtro
        ' 
        cmb_filtro.Name = "cmb_filtro"
        cmb_filtro.Size = New Size(121, 28)
        ' 
        ' ToolStrip1
        ' 
        ToolStrip1.BackColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        ToolStrip1.Font = New Font("Perpetua Titling MT", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        ToolStrip1.ImageScalingSize = New Size(20, 20)
        ToolStrip1.Items.AddRange(New ToolStripItem() {ToolStripLabel1, txt_pesquisa, ToolStripLabel2, cmb_filtro})
        ToolStrip1.Location = New Point(0, 0)
        ToolStrip1.Name = "ToolStrip1"
        ToolStrip1.Size = New Size(1145, 28)
        ToolStrip1.TabIndex = 1
        ToolStrip1.Text = "ToolStrip1"
        ' 
        ' Form10
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1145, 560)
        Controls.Add(ToolStrip1)
        Controls.Add(dgv_dados)
        Margin = New Padding(2)
        Name = "Form10"
        StartPosition = FormStartPosition.CenterScreen
        Text = "CLIENTES"
        CType(dgv_dados, ComponentModel.ISupportInitialize).EndInit()
        ToolStrip1.ResumeLayout(False)
        ToolStrip1.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents dgv_dados As DataGridView
    Friend WithEvents Column1 As DataGridViewTextBoxColumn
    Friend WithEvents Column2 As DataGridViewTextBoxColumn
    Friend WithEvents Column3 As DataGridViewTextBoxColumn
    Friend WithEvents Column4 As DataGridViewTextBoxColumn
    Friend WithEvents Column5 As DataGridViewTextBoxColumn
    Friend WithEvents ToolStripLabel1 As ToolStripLabel
    Friend WithEvents txt_pesquisa As ToolStripTextBox
    Friend WithEvents ToolStripLabel2 As ToolStripLabel
    Friend WithEvents cmb_filtro As ToolStripComboBox
    Friend WithEvents ToolStrip1 As ToolStrip
End Class
