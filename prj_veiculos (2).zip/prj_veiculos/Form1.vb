﻿Public Class form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        conecta_banco_mysql()
        txt_senha.UseSystemPasswordChar = True
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Form5.Show()
        Me.Hide()
    End Sub

    Private Sub btn_entrar_Click(sender As Object, e As EventArgs) Handles btn_entrar.Click
        Try
            ' Verifica se os campos estão vazios
            If txt_email.Text = "" Or txt_senha.Text = "" Then
                MsgBox("Preencha todos os campos.", MsgBoxStyle.Exclamation, "Aviso")
                txt_email.Clear()
                txt_senha.Clear()
                txt_email.Focus()
                Exit Sub
            End If

            ' Login do administrador fixo
            If txt_email.Text = "admin" And txt_senha.Text = "admin" Then
                MsgBox("Administrador logado com sucesso!", MsgBoxStyle.Information, "Aviso")
                Form3.Show()
                Me.Hide()
                Exit Sub
            End If

            ' Busca o cliente no banco
            sql = "SELECT * FROM clientes WHERE email = '" & txt_email.Text.Replace("'", "''") & "'"
            rs = db.Execute(sql)

            If rs.EOF Then
                MsgBox("Usuário não encontrado!", MsgBoxStyle.Exclamation, "Erro")
                txt_email.Clear()
                txt_senha.Clear()
                txt_email.Focus()
                Exit Sub
            End If

            ' Valida a senha
            Dim senhaBanco As String = rs.Fields("senha").Value.ToString()
            If txt_senha.Text <> senhaBanco Then
                MsgBox("Senha incorreta!", MsgBoxStyle.Exclamation, "Erro")
                txt_senha.Clear()
                txt_senha.Focus()
                Exit Sub
            End If

            ' Verifica se o usuário está bloqueado
            Dim statusBanco As String = rs.Fields("status").Value.ToString()
            If statusBanco.ToLower() = "bloqueado" Then
                MsgBox("Conta bloqueada! Entre em contato com o administrador.", MsgBoxStyle.Critical, "Acesso negado")
                txt_email.Clear()
                txt_senha.Clear()
                Exit Sub
            End If

            ' Login bem-sucedido
            MsgBox("Login realizado com sucesso!", MsgBoxStyle.Information, "Bem-vindo")
            Form2.Show()
            txt_email.Clear()
            txt_senha.Clear()
            Me.Hide()

        Catch ex As Exception
            MsgBox("Erro ao tentar logar: " & ex.Message, MsgBoxStyle.Critical, "Erro")
        End Try

    End Sub

    Private Sub chk_mostrar_CheckedChanged(sender As Object, e As EventArgs) Handles chk_mostrar.CheckedChanged
        txt_senha.UseSystemPasswordChar = Not chk_mostrar.Checked
    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click

    End Sub
End Class