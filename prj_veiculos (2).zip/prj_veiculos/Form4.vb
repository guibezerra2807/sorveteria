﻿Public Class Form4

    '===== QUANDO PRESSIONA ENTER NO TXT_CNH =====
    Private Sub txt_cnh_KeyDown(sender As Object, e As KeyEventArgs) Handles txt_cnh.KeyDown
        If e.KeyCode = Keys.Enter Then
            e.SuppressKeyPress = True
            buscar_cliente()
        End If
    End Sub

    '===== FUNÇÃO PARA BUSCAR CLIENTE =====
    Sub buscar_cliente()
        Try
            If Trim(txt_cnh.Text) = "" Then Exit Sub

            sql = "SELECT * FROM clientes WHERE cnh = '" & txt_cnh.Text.Replace("'", "''") & "'"
            rs = db.Execute(sql)

            If rs.EOF Then
                MsgBox("Cliente não encontrado!", MsgBoxStyle.Exclamation, "Aviso")
                Exit Sub
            End If

            ' Preenche os campos com os dados retornados
            txt_nome.Text = rs.Fields("nome").Value.ToString()
            txt_fone.Text = rs.Fields("telefone").Value.ToString()
            txt_email.Text = rs.Fields("email").Value.ToString()
            txt_cep.Text = rs.Fields("cep").Value.ToString()
            txt_senha.Text = rs.Fields("senha").Value.ToString()

            MsgBox("Dados carregados com sucesso!", MsgBoxStyle.Information, "Informação")

        Catch ex As Exception
            MsgBox("Erro ao buscar cliente: " & ex.Message, MsgBoxStyle.Critical, "Erro")
        End Try
    End Sub

    '===== SALVAR ALTERAÇÕES =====
    Private Sub btn_salvar_Click(sender As Object, e As EventArgs) Handles btn_salvar.Click
        Try
            If Trim(txt_cnh.Text) = "" Then
                MsgBox("Informe a CNH para atualizar os dados!", MsgBoxStyle.Exclamation, "Aviso")
                Exit Sub
            End If

            sql = "UPDATE clientes SET " &
                  "nome = '" & txt_nome.Text.Replace("'", "''") & "', " &
                  "telefone = '" & txt_fone.Text.Replace("'", "''") & "', " &
                  "email = '" & txt_email.Text.Replace("'", "''") & "', " &
                  "cep = '" & txt_cep.Text.Replace("'", "''") & "', " &
                  "senha = '" & txt_senha.Text.Replace("'", "''") & "' " &
                  "WHERE cnh = '" & txt_cnh.Text.Replace("'", "''") & "'"

            db.Execute(sql)

            MsgBox("Dados alterados com sucesso!", MsgBoxStyle.Information, "Sucesso")
            txt_cnh.Clear()
            txt_nome.Clear()
            txt_fone.Clear()
            txt_email.Clear()
            txt_cep.Clear()
            txt_senha.Clear()

        Catch ex As Exception
            MsgBox("Erro ao alterar os dados: " & ex.Message, MsgBoxStyle.Critical, "Erro")
        End Try
    End Sub

    '===== VOLTAR =====
    Private Sub btn_back_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Form4_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class